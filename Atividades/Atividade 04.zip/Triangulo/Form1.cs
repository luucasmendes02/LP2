﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Triangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double A, B, C;
            string Resultado;

            if (Double.TryParse(txtA.Text, out A) &&
                Double.TryParse(txtB.Text, out B) &&
                Double.TryParse(txtC.Text, out C))
            {
                if (((B - C) < A && A < B + C) && ((A - C) < B && B < A + C) && ((A - B) < C && C < A + B))
                {
                    if (A != B && A != C && B != C)
                    {
                        Resultado = "Escaleno";
                        txtResultado.Text = Resultado;
                        return;
                    }
                    else
                    {
                        if (A == B && A == C && B == C)
                        {
                            Resultado = "Equilátero";
                            txtResultado.Text = Resultado;
                        }
                        else
                        {
                            Resultado = "Isóceles";
                            txtResultado.Text = Resultado;
                        }
                    }
                }
                else
                {
                    Resultado = "Não é um triângulo";
                    txtResultado.Text = Resultado;
                }
            }
            else
            {
                Resultado = "Valores Inválidos";
                txtResultado.Text = Resultado;
            }
        }
        private void LimparCampos ()
        {
            txtA.Clear();
            txtB.Clear();
            txtC.Clear();
            txtResultado.Clear();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            LimparCampos ();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
